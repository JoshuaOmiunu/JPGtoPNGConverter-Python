from PIL import Image, ImageFilter

img = Image.open('./astro.jpg')  # album directory
  # lets try to size down this large photo

new_img = img.resize((400, 400))
new_img.save('thumbnail.jpg')  # squished in how do we fix?

# use thumbnail function
img.thumbnail((400, 381))
img.save('thumbnail.jpg')
print(img.size)
