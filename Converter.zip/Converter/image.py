from PIL import Image, ImageFilter

img = Image.open('./Albums/LOP.jpg')  # album directory
#
# print(img)
# print(img.format)
# print(img.mode) # attributes
# print(dir(img))

#  lets add some filters to photo
# filtered_img = img.filter(ImageFilter.BLUR)
# filtered_img.save("blur.png", 'png') # this will blur our album cover

filtered_img = img.filter(ImageFilter.SHARPEN)  # filter up photo
filtered_img.save("blur.png", 'png')

# change colour of photo
filtered_img = img.convert('L')  # change colour to grey
filtered_img.save("grey.png", 'png')

# filtered_img.show()  # view photo
crooked = filtered_img.rotate(180)
crooked.save('grey.png', 'png')  # rotate photo keeping the same file

# resize a photo
# resize = filtered_img.resize((300, 320))  # double bracket for tuple
# resize.save("grey.png", 'png')

#  crop a photo
box = (100, 100, 400, 400)
region = filtered_img.crop(box)
region.save('grey.png', 'png')